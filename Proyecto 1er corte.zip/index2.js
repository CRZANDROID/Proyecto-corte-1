listaU=JSON.parse(localStorage.getItem("listaUsuarios"))
localStorage.setItem("listaUsuarios",JSON.stringify(listaU)) 
