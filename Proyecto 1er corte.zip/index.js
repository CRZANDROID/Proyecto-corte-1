const lista=[ {user:"Martin", contra:12345 }]
localStorage.setItem("listaUsuarios",JSON.stringify(lista)) 
let usuario=" "
localStorage.setItem("nombre",usuario)
